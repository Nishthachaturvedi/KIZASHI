from fastapi import APIRouter
from routes.database import users_collection
from passlib.context import CryptContext

router = APIRouter()
pwd_context = CryptContext(schemes=["bcrypt"])

def hash_password(password):
    return pwd_context.hash(password)

def verify_password(password, hashed):
    return pwd_context.verify(password, hashed)

@router.post("/register")
def register(data: dict):
    user = users_collection.find_one({"email": data["email"]})
    if user:
        return {"error": "User exists"}

    users_collection.insert_one({
        "email": data["email"],
        "password": hash_password(data["password"])
    })

    return {"msg": "User created"}

@router.post("/login")
def login(data: dict):
    user = users_collection.find_one({"email": data["email"]})
    if not user:
        return {"error": "User not found"}

    if not verify_password(data["password"], user["password"]):
        return {"error": "Wrong password"}

    return {"msg": "Login success"}