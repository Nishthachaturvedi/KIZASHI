from fastapi import APIRouter
from routes.database import behaviour_collection
from datetime import datetime

router = APIRouter()

@router.post("/log")
def log_behaviour(data: dict):
    data["date"] = datetime.now().strftime("%Y-%m-%d")
    behaviour_collection.insert_one(data)
    return {"msg": "Saved"}

@router.get("/all")
def get_logs():
    data = list(behaviour_collection.find({}, {"_id": 0}))
    return data