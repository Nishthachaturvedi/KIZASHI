from fastapi import APIRouter
import joblib

router = APIRouter()

model = joblib.load("../ML/kizashi_model.pkl")
features = joblib.load("../ML/features.pkl")

@router.post("/predict")
def predict(data: dict):
    try:
        input_data = [data[f] for f in features]
        pred = model.predict([input_data])

        return {"prediction": pred[0]}
    except Exception as e:
        return {"error": str(e)}