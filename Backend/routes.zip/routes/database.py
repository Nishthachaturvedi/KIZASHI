from pymongo import MongoClient

client = MongoClient("mongodb://localhost:27017")
db = client["kizashi"]

users_collection = db["users"]
behaviour_collection = db["behaviour"]