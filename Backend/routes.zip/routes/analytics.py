from fastapi import APIRouter
from routes.database import behaviour_collection

router = APIRouter()

@router.get("/drift")
def drift():
    data = list(behaviour_collection.find({}, {"_id": 0}))

    if not data:
        return {"drift": 0}

    avg_study = sum(d["studyHours"] for d in data) / len(data)
    avg_screen = sum(d["screenTime"] for d in data) / len(data)

    drift_score = abs(avg_study * 10 - avg_screen * 5)

    return {"drift": round(drift_score)}

@router.get("/risk")
def risk():
    data = list(behaviour_collection.find({}, {"_id": 0}))

    if not data:
        return {}

    last = data[-1]

    risk = (last["screenTime"] * 5 + (100 - last["consistencyScore"])) / 2

    return {
        "productivityRisk": round(risk),
        "burnoutRisk": round(risk * 0.6)
    }

@router.get("/summary")
def summary():
    data = list(behaviour_collection.find({}, {"_id": 0}))

    if not data:
        return {}

    avg_study = sum(d["studyHours"] for d in data) / len(data)

    return {
        "avgStudyHours": round(avg_study, 2),
        "entries": len(data)
    }